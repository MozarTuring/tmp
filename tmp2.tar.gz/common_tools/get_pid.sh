cmd=`ps -ef|grep python|grep maojing+`

echo "$cmd" > /home/maojingwei/tmp.pid
