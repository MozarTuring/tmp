cd $1
git add .
git commit -m "from $repo $version"
git remote add origin $3